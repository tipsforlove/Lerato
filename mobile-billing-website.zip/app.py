from flask import Flask, request, redirect, render_template_string
app = Flask(__name__)

index_html = open("index.html").read()

@app.route("/", methods=["GET"])
def home():
    return index_html

@app.route("/subscribe", methods=["POST"])
def subscribe():
    mobile = request.form.get("mobile")
    # Simulated subscription logic (to replace with real billing API call)
    print(f"Subscribed: {mobile} - Charging R3/day...")
    return f"Mobile number {mobile} subscribed successfully. Billing R3/day."

if __name__ == "__main__":
    app.run(debug=True)
